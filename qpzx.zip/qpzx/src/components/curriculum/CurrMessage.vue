<template>
  <div class="shade">
    <Card>
      <p slot="title" v-if="$parent.isUpdata">编辑课程</p>
      <p slot="title" v-else>新建课程</p>
      <p slot="extra" class="extra" @click="close">×</p>
      <p class="contanner">
        <Form ref="form" :model="form" :rules="ruleValidate" :label-width="80">
          <Row>
            <Col span="11">
              <FormItem label="课程类型" prop="type">
                <Select v-model="form.type" placeholder="请选择" @on-change="getSelected">
                  <Option :value="1">直播</Option> 
                  <Option :value="2">微课</Option> 
                </Select>
              </FormItem>
            </Col>
            <Col span="11" offset="2">
              <FormItem label="年级" prop="grade">
                <Select v-model="form.grade" placeholder="请选择">
                  <Option :value="1">一年级</Option> 
                  <Option :value="2">二年级</Option> 
                  <Option :value="3">三年级</Option> 
                  <Option :value="4">四年级</Option> 
                  <Option :value="5">五年级</Option> 
                  <Option :value="6">六年级</Option> 
                  <Option :value="7">七年级</Option> 
                  <Option :value="8">八年级</Option> 
                  <Option :value="9">九年级</Option> 
                </Select>
              </FormItem>
            </Col>
            <Col span="11">
              <FormItem label="课程名称" prop="course_name">
                <Input v-model="form.course_name" placeholder="请输入副标题"></Input>
              </FormItem>
            </Col>
            <Col span="11" offset="2">
              <FormItem label="科目" prop="subject">
                <Select v-model="form.subject" placeholder="请选择">
                  <Option :value="1">数学</Option> 
                  <Option :value="2">英语</Option> 
                  <Option :value="3">语文</Option> 
                  <Option :value="4">物理</Option> 
                  <Option :value="5">化学</Option> 
                  <Option :value="6">政治</Option> 
                  <Option :value="7">生物</Option> 
                  <Option :value="8">地理</Option> 
                  <Option :value="9">历史</Option> 
                </Select>
              </FormItem>
            </COl>
            <Col span="24">
              <FormItem label="轮播图片展示" v-if="form.iamge_1 || form.iamge_2 || form.iamge_3">
                <div class="demo-upload-list" v-if="form.iamge_1">
                  <img :src="'http://liveapi.canpoint.net/'+form.iamge_1">
                  <div class="demo-upload-list-cover">
                    <Icon type="ios-eye-outline" @click.native="handleView('http://liveapi.canpoint.net/'+form.iamge_1)"></Icon>
                  </div>
                </div>
                <div class="demo-upload-list" v-if="form.iamge_2">
                  <img :src="'http://liveapi.canpoint.net/'+form.iamge_2">
                  <div class="demo-upload-list-cover">
                    <Icon type="ios-eye-outline" @click.native="handleView('http://liveapi.canpoint.net/'+form.iamge_2)"></Icon>
                  </div>
                </div>
                <div class="demo-upload-list" v-if="form.iamge_3">
                  <img :src="'http://liveapi.canpoint.net/'+form.iamge_3">
                  <div class="demo-upload-list-cover">
                    <Icon type="ios-eye-outline" @click.native="handleView('http://liveapi.canpoint.net/'+form.iamge_3)"></Icon>
                  </div>
                </div>
                <Modal title="View Image" v-model="visible">
                  <img :src="imgName" style="width: 100%">
                </Modal>
              </FormItem>
            </col>
            <Col span="24">
              <FormItem label="轮播图片" prop="image_1" class="active_span" v-if="form.type == 1">
                <span class="active_red">*</span>
                <template>
                  <div class="demo-upload-list" v-for="item in uploadList">
                    <img :src="item.url">
                    <div class="demo-upload-list-cover">
                      <Icon type="ios-trash-outline" @click.native="handleRemove(item)"></Icon>
                    </div>
                  </div>
                </template>
                <Upload ref="upload" :show-upload-list="false" 
                  :format="['jpg','gif','png']"
                  :max-size="2048" 
                  :before-upload="handleBeforeUpload" 
                  :on-format-error="handleFormatError" 
                  :on-exceeded-size="handleMaxSize" 
                  type="drag" 
                  action="//jsonplaceholder.typicode.com/posts/" 
                  style="display: inline-block;width:58px;">
                  <div style="width: 58px;height:58px;line-height: 58px;">
                    <Icon type="ios-camera" size="20"></Icon>
                  </div>
                </Upload>
                <p>只能上传jpg/png格式文件，文件不能超过2M，图片尺寸：180px * 180px</p>
              </FormItem>
            </Col>
            <Col  span="24">
            <FormItem label="微课视频" prop="video" class="active_span" v-if="isVideo">
              <span class="active_red">*</span>
              <input type="file" ref="file" @change="uploadMp4($event)">
            </FormItem>
            </Col>
            <Col span="5">
              <FormItem label="课程周期" prop="start_date">
                 <DatePicker v-model="form.start_date" @on-change="getStart" type="date" placeholder="选择该课程开始时间" style="width: 200px"></DatePicker>
              </FormItem>
            </Col>
            <Col span="5">
              <FormItem prop="end_date">
                <DatePicker  v-model="form.end_date" @on-change="getEnd" type="date" placeholder="选择该课程结束时间" style="width: 200px"></DatePicker>
              </FormItem>
            </Col>
            <FormItem prop="week_day">

            </FormItem>
            <!-- <Col span="6">
              <FormItem prop="week_day">
                <Select v-model="form.week_day" placeholder="请选择">
                  <Option :value="1">周一</Option> 
                  <Option :value="2">周二</Option> 
                  <Option :value="3">周三</Option> 
                  <Option :value="4">周四</Option> 
                  <Option :value="5">周五</Option> 
                  <Option :value="6">周六</Option> 
                  <Option :value="7">周日</Option> 
                </Select>
              </FormItem>
            </Col>
            <Col span="3">
              <FormItem prop="start_time">
                <TimePicker v-model="form.start_time" @on-change="getStartTime" format="HH:mm" placeholder="选择开始时间" style="width: 140px"></TimePicker>
              </FormItem>
            </Col>
            <Col span="3">
              <FormItem prop="end_time">
                <TimePicker v-model="form.end_time" @on-change="getEndTime" format="HH:mm" placeholder="选择结束时间" style="width: 140px"></TimePicker>
              </FormItem>
            </Col> -->
          </Row>
          <FormItem label="课程详情" prop="product_content">
				    <Wangeditor v-model="form.product_content"  :catchData="catchData" ref="wangditor"/>
          </FormItem>
        <FormItem label="课程数" prop="class_hour">
          <Input v-model="form.class_hour" placeholder="请输入副标题"></Input>
        </FormItem>
        <FormItem label="售价" prop="sale_price">
          <Input v-model="form.sale_price" placeholder="请输入副标题"></Input>
        </FormItem>
        <FormItem label="活动价" prop="activity_price">
          <Input v-model="form.activity_price" placeholder="请输入该课程优惠价格"></Input>
        </FormItem>
        <FormItem label="教室链接" prop="class_url">
          <Input v-model="form.class_url" placeholder="请输入教室链接"></Input>
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('form')">确定</Button>
          <Button @click="handleReset('form')" style="margin-left: 8px">重置</Button>
        </FormItem>
    </Form>
      </p>
    </Card>
  </div>
</template>

<script>
import Wangeditor from '../../uilt/wangeditor/Wangeditor'
import { mapActions } from 'vuex'
import storage from '../../uilt/storage'
import axios from 'axios'
export default {
  props:["item"],
	components:{
		Wangeditor
	},
  data() {
    return {
      isVideo:false,
      uploadMp4List:[],
      endTime:"",
      startTime:"",
      end:"",
      start:"",
      file:[],
      imgUrl:"",
      imgName: '',
      visible: false,
      uploadList: [],
      form: {
        product_content:"123456",
        type:1
      },
      ruleValidate: {
        type: [
          { required: true, message: '课程类型不能为空'}
        ],
        grade: [
          { required: true, message: '年级不能为空'}
        ],
        course_name: [
          { required: true, message: '课程名称不能为空', trigger: 'blur' }
        ],
        subject: [
          { required: true, message: '科目不能为空'}
        ],
        class_hour: [
          { required: true, message: '课节数不能为空' }
        ],
        sale_price: [
          { required: true, message: '售价不能为空', trigger: 'blur' }
        ],
        activity_price: [
          { required: true, message: '活动价不能为空', trigger: 'blur' }
        ],
        product_content:[{ required: true}],
        start_date:[{ required: true}],
      }
    };
  },
  methods: {
    ...mapActions(["addCurrList","updataCurrList","getCurrList"]),
    getSelected(){
      if(this.form.type == 1){
        this.isVideo = false
      }else{
        this.isVideo = true
      }
    },
    //视频
    uploadMp4(e){
      const check = this.uploadMp4List.length;
      if (check >=3) {
        this.$Message.error('最多只能上传3张图片');
        return;
      }
      let file = e.target.files[0]
      let reader = new FileReader()
      reader.readAsDataURL(file)
      const _this = this
      reader.onloadend = function (e) {
        file.url = reader.result
        _this.uploadMp4List.push(file)
      }
    },
    // //结束时间
    // getEndTime(date){
    //   this.endTime = date
    // },
    // //开始时间
    // getStartTime(date){
    //   this.startTime = date
    // },
    //课程结束日期
    getEnd(date){
      this.end = date
    },
    //课程开始日期
    getStart(date){
      this.start = date
    },
		catchData(val){
      this.form.product_content = val
		},
    handleView (item) {
      if(this.$parent.isUpdata){
        this.imgName = item
      }else{
        this.imgName = this.uploadList.url;
      }
      this.visible = true;
    },
    handleRemove (file) {
      this.uploadList.splice(this.uploadList.indexOf(file), 1)
    },
    handleFormatError (file) {
      this.$Notice.warning({
        title: '文件格式不正确',
        desc: '文件' + file.name + '格式不正确，请选择jpg或png。'
      });
    },
    handleMaxSize (file) {
      this.$Notice.warning({
        title: '超过档案大小限制',
        desc: '文件 ' + file.name + '太大了，不超过2M。'
      });
    },
    handleBeforeUpload (file) {
      const check = this.uploadList.length;
      if (check >=3) {
        this.$Message.error('最多只能上传3张图片');
        return;
      }
      let reader = new FileReader()
      reader.readAsDataURL(file)
      const _this = this
      reader.onloadend = function (e) {
        file.url = reader.result
        _this.uploadList.push(file)
      }
    },
    close() {
      this.$parent.isCurrMessage = false;
    },
    handleSubmit (name) {
      this.$refs[name].validate((valid) => {
        if (valid) {
          if(this.$parent.isUpdata){
            var d = new Date(this.form.start_date);
            var b = new Date(this.form.end_date);
            var formData = new FormData();
            formData.append('id', this.form.id);
            formData.append('type', this.form.type);
            formData.append('grade',this.form.grade);
            formData.append('subject',this.form.subject);
            formData.append('course_name',this.form.course_name);
            formData.append('product_content',this.form.product_content);
            formData.append('start_date',d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate());
            formData.append('end_date',b.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate());
            formData.append('week_day',this.form.week_day);
            // formData.append('start_time',this.form.start_time);
            // formData.append('end_time',this.form.end_time);
            formData.append('class_hour',this.form.class_hour);
            formData.append('class_url',this.form.class_url);
            formData.append('activity_price',this.form.activity_price);
            formData.append('sale_price',this.form.sale_price);
            formData.append('video',this.uploadMp4List[0]?this.uploadMp4List[0] :"");
            formData.append('image_1',this.uploadList[0]?this.uploadList[0]:"");
            formData.append('image_2',this.uploadList[1]?this.uploadList[1]:"");
            formData.append('image_3',this.uploadList[2]?this.uploadList[2]:"");
             let config = {
              headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: "bearer " + storage.get()
              }
            };
            axios.post("http://liveapi.canpoint.net/api/update_products" , formData,config)
            .then((response) => {
              if(response.data.code == 100001 && response.data.error){
                this.$Message.error(response.data.error);
              }
              if(response.data.code==200 && response.data.ret == true){
                this.$Message.success("修改成功");
                this.getCurrList()
                this.$parent.isCurrMessage = false
              }
            })
          }else{
            var formData = new FormData();
            formData.append('type', this.form.type);
            formData.append('grade',this.form.grade);
            formData.append('subject',this.form.subject);
            formData.append('course_name',this.form.course_name);
            formData.append('product_content',this.form.product_content);
            formData.append('start_date',this.start);
            formData.append('end_date',this.end);
            formData.append('week_day',this.form.week_day);
            // formData.append('start_time',this.startTime);
            // formData.append('end_time',this.endTime);
            formData.append('class_hour',this.form.class_hour);
            formData.append('sale_price',this.form.sale_price);
            formData.append('activity_price',this.form.activity_price);
            formData.append('class_url',this.form.class_url);
            formData.append('video',this.uploadMp4List[0]?this.uploadMp4List[0] :"");
            formData.append('image_1',this.uploadList[0]?this.uploadList[0]:"");
            formData.append('image_2',this.uploadList[1]?this.uploadList[1]:"");
            formData.append('image_3',this.uploadList[2]?this.uploadList[2]:"");
            if( this.form.type == 2 && this.uploadMp4List.length == 0){
              this.$Message.warning('请选择要上传的视频')
              return
            }
            if(this.form.type == 1 && this.uploadList.length == 0){
              this.$Message.warning('请选择要上传的图片')
              return
            }
            if(!this.form.product_content){
              this.$Message.warning('请填写专题内容')
              return
            }
             let config = {
              headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: "bearer " + storage.get()
              }
            };
            axios.post("http://liveapi.canpoint.net/api/create_products",formData,config)
            .then((response) => {
              if(response.data.code == 100001 && response.data.
              
              
              error){
                this.$Message.error(response.data.error);
              }
              if(response.data.code==200 && response.data.ret == true){
                this.$Message.success("新增成功");
                this.getCurrList()
                this.$parent.isCurrMessage = false
              }
            })
          }
        } else {
          this.$Message.error('请完整填写正确信息');
        }
      })
    },
    handleReset (name) {
      this.$refs[name].resetFields();
    }
  },
  mounted () {
    this.$refs.wangditor.text = ""
    if(this.$parent.isUpdata){
      this.form =  this.item
      this.$refs.wangditor.text = this.item.product_content
    }else{
      this.uploadList.length = 0
    }
  }
};
</script>

<style scoped>
.ivu-picker-panel-body.ivu-picker-panel-body-date{
  position: relative;
  z-index: 9999;
}
#wangeditor{
  position: relative;
  z-index: 99;
}
.demo-upload-list{
  display: inline-block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  border: 1px solid transparent;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  box-shadow: 0 1px 1px rgba(0,0,0,.2);
  margin-right: 4px;
}
.demo-upload-list img{
  width: 100%;
  height: 100%;
}
.demo-upload-list-cover{
  display: none;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0,0,0,.6);
}
.demo-upload-list:hover .demo-upload-list-cover{
  display: block;
}
.demo-upload-list-cover i{
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 2px;
}
/*  */
.ivu-radio.ivu-radio-checked span{
  box-sizing: border-box;
}
.label-left{
  margin-left: -25px;
}
.contanner{
  margin: 20px 20px 20px 0;
}
.extra {
  font-size: 25px;
  cursor: pointer;
}
.shade {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
  background: rgba(0, 0, 0, 0.3);
}
.ivu-form.ivu-form-label-right{
  height: 500px!important;
  overflow-y: auto!important;
}
.ivu-card.ivu-card-bordered {
  width: 1200px;
  height: 600px;
}
</style>